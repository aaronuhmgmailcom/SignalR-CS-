﻿using Microsoft.AspNet.SignalR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

public class myhub : Hub
{
    private static List<Myc> userm;
    public void Send(string name, string message)
    {
        //客户端调用的方法
        Clients.All.addMessage(name, message);
    }
    //服务器端
    public void testsend(string id, string message)
    {
        //客户端调用方法
        Clients.Client(id).mysend(message);
    }
    public void Send2(Myc mc)
    {
        mc.name = Context.ConnectionId;
        //调用前端代码
        // Clients.Client(Context.ConnectionId).sendmessage(Context.ConnectionId,message);
        Clients.All.sendmessage(mc);
    }

    /// <summary>
    /// 客户端连接服务器成功后调用
    /// </summary>
    /// <returns></returns>
    public override Task OnConnected()
    {
        if (userm == null)
        {
            userm = new List<Myc>();
        }
        userm.Add(new Myc { id = Context.ConnectionId, status = true, t = DateTime.Now });
        Clients.All.onlineuser(userm);
        // 在这添加代码.   
        // 例如:在一个聊天程序中,记录当前连接的用户ID和名称,并标记用户在线.
        // 在该方法中的代码完成后,通知客户端建立连接,客户端代码
        // start().done(function(){//你的代码});
        return base.OnConnected();
    }
    /// <summary>
    /// 客户端断开连接后调用
    /// </summary>
    /// <param name="stopcalled"></param>
    /// <returns></returns>
    public override Task OnDisconnected(bool stopcalled)
    {
        if (userm == null)
        {
            userm = new List<Myc>();
        }
        userm.Remove((from u in userm where u.id == Context.ConnectionId select u).ToList()[0]);
        Clients.All.onlineuser(userm);
        // 在这添加代码.
        // 例如: 标记用户离线 
        // 删除连接ID与用户的关联.
        return base.OnDisconnected(stopcalled);
    }

}
public class Myc
{
    public string id { get; set; }
    public string name { get; set; }
    public bool status { get; set; }
    public DateTime t { get; set; }
}