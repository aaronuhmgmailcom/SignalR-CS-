﻿using Microsoft.AspNet.SignalR.Client;
using Microsoft.Owin.Hosting;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        HubConnection connection = null;
        IHubProxy rhub = null;
        public IDisposable SignalR2 { get; set; }
        private const string ServerUri2 = "http://localhost:8889"; // SignalR服务地址，自定义
        private void button1_Click(object sender, EventArgs e)
        {
            Task.Run(() => { StartServer(); }); // 异步启动SignalR服务
            label2.Text = "Service start successful!" + ServerUri2;
        }
        private bool StartServer()
        {
            try
            {


                SignalR2 = WebApp.Start(ServerUri2);
                /*下面代码是为了获取当前连接的客户端信息*/
                //获取连接客户端信息
                connection = new HubConnection(ServerUri2);
                rhub = connection.CreateHubProxy("myhub");
                connection.Start();//连接服务器  

                rhub.On<List<Myc>>("onlineuser", onlienuser);
                rhub.On<string, string>("addMessage", ReceiveMsg);
            }
            catch (Exception ex)
            {
                return false;
            }
            return true;
        }
        private void ReceiveMsg(string name, string message)
        {
            Thread viewthread2 = new Thread(viewincrease2);
            viewthread2.Start("New message:" + message + " Datetime:" + DateTime.Now + " Instance id:" + name );
        }
        public void viewincrease2(object obj)
        {
            string message = obj as string;
            if (listBox2.InvokeRequired)
            {
                Action<string> listbox = (x) => { this.listBox2.Items.Add(message); };
                listBox2.Invoke(listbox, message);
            }
        }
        private bool StopServer()
        {
            try
            {
                SignalR2.Dispose();

            }
            catch (Exception ex)
            {
                return false;

            }
            return true;
        }

        public void onlienuser(List<Myc> ou)
        {

            Thread viewthread = new Thread(viewincrease);
            viewthread.Start(ou);
        }
        public void viewincrease(object obj1)
        {
            List<Myc> obj = obj1 as List<Myc>;
            if (label1.InvokeRequired)
            {
                Action<string> label = (x) => { this.label1.Text = obj.Count.ToString(); };
                label1.Invoke(label, obj.Count.ToString());
            }
            if (listBox1.InvokeRequired)
            {
                Action<string> listb = (x) => { this.listBox1.Items.Clear(); };
                listBox1.Invoke(listb, "");
                foreach (Myc m in obj)
                {
                    Action<string> listbox = (x) => { this.listBox1.Items.Add("New connection id:" + m.id + " Status:" + m.status + " DateTime:" + m.t); };
                    listBox1.Invoke(listbox, "id:" + m.id + " status:" + m.status + " T:" + m.t);
                }

            }

        }
        private void button2_Click(object sender, EventArgs e)
        {
            label2.Text = "Stop Server";
            Task.Run(() => { StopServer(); });
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string m = textBox1.Text;
            string id = connection.ConnectionId;
            //调用 hub中的方法 Send
            rhub.Invoke("Send", id, m).Wait();
        }
    }
}
