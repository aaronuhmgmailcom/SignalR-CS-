﻿using Microsoft.AspNet.SignalR.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        HubConnection connection = null;
        IHubProxy rhub = null;
        private const string ServerUri = "http://localhost:8889";
        private void button1_Click(object sender, EventArgs e)
        {
            connection = new HubConnection(ServerUri);
            //类名必须与服务端一致
            //myHub = connection.CreateHubProxy("BroadcastHub");                  
            rhub = connection.CreateHubProxy("myhub");
            connection.Start();//连接服务器  
            label1.Text = "Connect to server successful！";
            //注册客户端方法名称"addMessage"与服务器端Send方法对应，对应的 callback方法 ReceiveMsg
            rhub.On<string, string>("addMessage", ReceiveMsg);
        }
        /// <summary>
        /// 对应的callback方法
        /// </summary>
        /// <param name="name"></param>
        /// <param name="message"></param>
        private void ReceiveMsg(string name, string message)
        {
            Thread viewthread = new Thread(viewincrease);
            viewthread.Start("Server Message :" + message + " DateTime:" + DateTime.Now + " Instance id:" + name );
        }
        /// <summary>
        /// 发送消息
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
       


        public void viewincrease(object obj)
        {
            string message = obj as string;
            if (listBox1.InvokeRequired)
            {
                Action<string> listbox = (x) => { this.listBox1.Items.Add(message); };
                listBox1.Invoke(listbox, message);
            }
        }

       
    }
}
