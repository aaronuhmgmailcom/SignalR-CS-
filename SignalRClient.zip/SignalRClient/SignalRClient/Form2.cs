﻿using Microsoft.AspNet.SignalR.Client;
using Microsoft.Owin.Hosting;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        public IDisposable SignalR2 { get; set; }
        private const string ServerUri2 = "http://localhost:8889"; // SignalR服务地址，自定义
        private void button1_Click(object sender, EventArgs e)
        {
            Task.Run(() => { StartServer(); }); // 异步启动SignalR服务
            label2.Text = "服务启动成功" + ServerUri2;
        }
        private bool StartServer()
        {
            try
            {


                SignalR2 = WebApp.Start(ServerUri2);
                /*下面代码是为了获取当前连接的客户端信息*/
                //获取连接客户端信息
                HubConnection connection = new HubConnection(ServerUri2);
                IHubProxy rhub = connection.CreateHubProxy("myhub");
                connection.Start();//连接服务器  

                rhub.On<List<Myc>>("onlineuser", onlienuser);
            }
            catch (Exception ex)
            {
                return false;
            }
            return true;
        }

        private bool StopServer()
        {
            try
            {
                SignalR2.Dispose();

            }
            catch (Exception ex)
            {
                return false;

            }
            return true;
        }

        public void onlienuser(List<Myc> ou)
        {

            Thread viewthread = new Thread(viewincrease);
            viewthread.Start(ou);
        }
        public void viewincrease(object obj1)
        {
            List<Myc> obj = obj1 as List<Myc>;
            if (label1.InvokeRequired)
            {
                Action<string> label = (x) => { this.label1.Text = obj.Count.ToString(); };
                label1.Invoke(label, obj.Count.ToString());
            }
            if (listBox1.InvokeRequired)
            {
                Action<string> listb = (x) => { this.listBox1.Items.Clear(); };
                listBox1.Invoke(listb, "");
                foreach (Myc m in obj)
                {
                    Action<string> listbox = (x) => { this.listBox1.Items.Add("id:" + m.id + " status:" + m.status + " T:" + m.t); };
                    listBox1.Invoke(listbox, "id:" + m.id + " status:" + m.status + " T:" + m.t);
                }

            }

        }
        private void button2_Click(object sender, EventArgs e)
        {
            label2.Text = "关闭";
            Task.Run(() => { StopServer(); });
        }
    }
}
